﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports; // to access the serial port

namespace Waspmote_WSN
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            getAvailablePorts();
        }

        void getAvailablePorts()
        {
            // Get a list of existing ports
            String[] ports = SerialPort.GetPortNames();
            String[] baudrates = new String[] { "9600", "115200" };

            // Insert the lists into the combo boxes
            comboBox1.Items.AddRange(ports);
            comboBox2.Items.AddRange(baudrates);

            //select the default setting if at least a com port is found
            if (ports.Count() != 0)
            {
                comboBox1.SelectedIndex = 0;
                comboBox2.SelectedIndex = 1;
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            string value = sp.ReadExisting();
            processValue(value);
        }

        //Delegate to update received data in the textbox private

        delegate void processValueDelegate(string value);

        private void processValue(string value)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke(new processValueDelegate(processValue), new object[] { value });
            }
            else
            {
                // ... update GUI in here ...
                textBox1.AppendText(value);
                DataExtraction(value);
            }
        }

        string UnreadBuffer = "";

        private void DataExtraction(string RxString)
        {
            UnreadBuffer += RxString;

            //Search for Data Header "<=>"

            int start = UnreadBuffer.IndexOf("<=>");
            int delimiter = UnreadBuffer.IndexOf("#");
            if (start >= 0)
            {
                string row = UnreadBuffer.Substring(start);
                if (delimiter >= 0)
                {
                    string[] ExtractedDataFields = row.Split('#');

                    if (ExtractedDataFields.Length >= 7)
                    {
                        textBox2.Text = string.Format("{0:HH:mm:ss tt}", DateTime.Now);
                        textBox3.Text = ExtractedDataFields[1];
                        textBox4.Text = ExtractedDataFields[2];
                        textBox5.Text = ExtractedDataFields[3];
                        textBox6.Text = ExtractedDataFields[4];
                        UnreadBuffer = "";
                    }
                }
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.Text == "" || comboBox2.Text == "")
                {
                    textBox1.Text = "Please select port settings";
                }
                else
                {
                    serialPort1.PortName = comboBox1.Text;
                    serialPort1.BaudRate = Convert.ToInt32(comboBox2.Text);
                    serialPort1.DataReceived += new SerialDataReceivedEventHandler(serialPort1_DataReceived);
                    serialPort1.Open();
                    progressBar1.Value = 100;

                    button1.Enabled = false;
                    button2.Enabled = true;
                }
            }
            catch (UnauthorizedAccessException)
            {
                textBox1.Text = "UnauthorizedAccess";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            serialPort1.Close();
            progressBar1.Value = 0;
            button1.Enabled = true;
            button2.Enabled = false;
        }
    }
}
